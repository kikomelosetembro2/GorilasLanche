import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { MenuCatalog } from './components/MenuCatalog';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { DeliveryCalculatorModal } from './components/DeliveryCalculatorModal';
import { ThermalReceipt } from './components/ThermalReceipt';
import { ArchitectureGuide } from './components/ArchitectureGuide';
import { ProjectDownloadModal } from './components/ProjectDownloadModal';
import { SharePublicModal } from './components/SharePublicModal';
import { ENRICHED_MENU_ITEMS, RESTAURANT_INFO } from './data/menuData';
import { MenuItem, CartItem, Order } from './types';
import { ShoppingBag, ArrowRight, MessageCircle, Download, Globe, Sparkles, Check, Copy, Bike, FileCode, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'catalog' | 'receipt' | 'architecture'>('catalog');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<MenuItem | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [isDeliveryCalcOpen, setIsDeliveryCalcOpen] = useState<boolean>(false);
  const [isDownloadOpen, setIsDownloadOpen] = useState<boolean>(false);
  const [isShareOpen, setIsShareOpen] = useState<boolean>(false);
  const [copiedPublicLink, setCopiedPublicLink] = useState<boolean>(false);
  const [isCartAnimating, setIsCartAnimating] = useState<boolean>(false);

  const publicAppUrl = 'https://ais-pre-ic5lzjsyno5gxudax3k63z-478599787022.us-east5.run.app';

  // Initial demo order so the Thermal Receipt is immediately interactive
  const [currentOrder, setCurrentOrder] = useState<Order | null>({
    id: 'GOR-1042',
    createdAt: new Date().toISOString(),
    customer: {
      name: 'Carlos Albuquerque',
      phone: '(68) 99227-7408',
      deliveryType: 'delivery',
      address: {
        street: 'Rua Floriano Peixoto',
        number: '480',
        neighborhood: 'Bosque',
        complement: 'Apto 302',
        reference: 'Próximo à pracinha',
        distanceKm: 2.5,
        tierName: 'Faixa 2 — Raio Próximo (2.1 a 4.0 km)',
        estimatedMinutes: '25 a 40 min',
        isFreeDelivery: false,
      },
      paymentMethod: 'pix',
      couponCode: 'GORILLA10',
    },
    items: [
      {
        cartItemId: 'item-demo-1',
        product: ENRICHED_MENU_ITEMS[5], // X-Bagunça
        quantity: 1,
        selectedAddons: [
          { id: 'add-queijo', name: 'Queijo Duplo Derretido', price: 3.5, quantity: 1 },
          { id: 'add-bacon', name: 'Bacon Crocante Fatiado', price: 4.5, quantity: 1 },
        ],
        removedIngredients: ['Sem Cebola'],
        notes: 'Carne bem passada por favor',
        unitPrice: 32.0,
        totalPrice: 32.0,
      },
      {
        cartItemId: 'item-demo-2',
        product: ENRICHED_MENU_ITEMS[0], // Combo 1
        quantity: 1,
        selectedAddons: [],
        removedIngredients: [],
        unitPrice: 22.0,
        totalPrice: 22.0,
      },
    ],
    subtotal: 54.0,
    deliveryFee: 7.0,
    discount: 5.4,
    total: 55.6,
    status: 'recebido',
  });

  // Calculate cart count & subtotal
  const { cartCount, cartSubtotal } = useMemo(() => {
    let count = 0;
    let subtotal = 0;
    cartItems.forEach((item) => {
      count += item.quantity;
      subtotal += item.totalPrice;
    });
    return { cartCount: count, cartSubtotal: subtotal };
  }, [cartItems]);

  // Cart operations with shake & bounce feedback animation
  const handleAddToCart = (newItem: CartItem) => {
    setCartItems((prev) => [...prev, newItem]);
    setIsCartAnimating(true);
    setTimeout(() => {
      setIsCartAnimating(false);
    }, 800);
  };

  const handleUpdateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(cartItemId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => {
        if (item.cartItemId === cartItemId) {
          return {
            ...item,
            quantity: newQty,
            totalPrice: item.unitPrice * newQty,
          };
        }
        return item;
      })
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCartItems((prev) => prev.filter((item) => item.cartItemId !== cartItemId));
  };

  const handleOrderCreated = (order: Order) => {
    setCurrentOrder(order);
    setCartItems([]);
    setIsCheckoutOpen(false);
  };

  const handleUpdateStatus = (newStatus: Order['status']) => {
    if (currentOrder) {
      setCurrentOrder({ ...currentOrder, status: newStatus });
    }
  };

  const handleCopyPublicLink = () => {
    navigator.clipboard.writeText(publicAppUrl);
    setCopiedPublicLink(true);
    setTimeout(() => setCopiedPublicLink(false), 2500);
  };

  return (
    <div className="min-h-screen bg-[#FFFFFF] text-[#1F1F1F] font-sans selection:bg-[#FF7A00] selection:text-white flex flex-col">
      {/* Top Header - Fundo #FFFFFF com novo tema */}
      <Header
        restaurant={RESTAURANT_INFO}
        cartCount={cartCount}
        cartTotal={cartSubtotal}
        onOpenCart={() => setIsCartOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDownload={() => setIsDownloadOpen(true)}
        onOpenShare={() => setIsShareOpen(true)}
        isCartAnimating={isCartAnimating}
      />

      {/* Main Responsive Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-4 sm:py-6 text-[#1F1F1F] bg-[#FFFFFF]">
        {/* Banner de Status e Ações Rápidas de Download HTML */}
        {activeTab === 'catalog' && (
          <div className="mb-5 p-4 sm:p-5 rounded-2xl bg-[#FFF1E6] border border-[#FF7A00]/30 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white text-[#FF7A00] flex items-center justify-center font-bold shrink-0 border border-[#FF7A00]/40 shadow-xs">
                <FileCode className="w-5 h-5 text-[#FF7A00]" />
              </div>
              <div className="text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-[#1F1F1F]">
                    Aplicativo Disponível para Execução Local ou Web:
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    100% EXECUTÁVEL
                  </span>
                </div>
                <p className="text-[#1F1F1F]/70 text-[11px] mt-0.5 max-w-md">
                  Baixe o arquivo HTML standalone para abrir com 2 cliques em qualquer navegador ou o pacote ZIP completo.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto shrink-0">
              <button
                type="button"
                onClick={() => setIsDownloadOpen(true)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#FF7A00] hover:bg-[#E04E0C] text-white font-bold text-xs shadow-xs transition-all active:scale-95"
              >
                <Download className="w-4 h-4 text-white" />
                <span>Baixar Código HTML</span>
              </button>

              <button
                type="button"
                onClick={() => setIsDeliveryCalcOpen(true)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-white hover:bg-[#FFF1E6] text-[#1F1F1F] font-bold text-xs border border-[#FF7A00]/25 transition-colors"
                title="Simular frete por km"
              >
                <Bike className="w-4 h-4 text-[#FF7A00]" />
                <span>Calcular Frete (km)</span>
              </button>

              <button
                type="button"
                onClick={handleCopyPublicLink}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-[#FFF1E6] text-[#1F1F1F] font-semibold text-xs border border-[#FF7A00]/25 transition-colors"
              >
                {copiedPublicLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-[#1F1F1F]" />}
                <span>{copiedPublicLink ? 'Copiado!' : 'Copiar Link'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsShareOpen(true)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-[#FFF1E6] text-[#1F1F1F] font-semibold text-xs border border-[#FF7A00]/25 transition-colors"
              >
                <Globe className="w-4 h-4 text-[#FF7A00]" />
                <span>QR Code</span>
              </button>
            </div>
          </div>
        )}

        {activeTab === 'catalog' && (
          <MenuCatalog
            items={ENRICHED_MENU_ITEMS}
            onSelectItem={(item) => setSelectedProduct(item)}
            onOpenDeliveryCalculator={() => setIsDeliveryCalcOpen(true)}
          />
        )}

        {activeTab === 'receipt' && (
          <ThermalReceipt
            order={currentOrder}
            restaurant={RESTAURANT_INFO}
            onUpdateStatus={handleUpdateStatus}
          />
        )}

        {activeTab === 'architecture' && <ArchitectureGuide />}
      </main>

      {/* Mobile Floating WhatsApp Quick Button when cart is empty */}
      {cartCount === 0 && activeTab === 'catalog' && (
        <aside
          aria-label="Pedir no WhatsApp"
          className="fixed bottom-4 right-4 sm:hidden z-30 animate-in slide-in-from-bottom-2 duration-300"
        >
          <a
            href={`https://wa.me/${RESTAURANT_INFO.whatsappFormatted}?text=${encodeURIComponent('Olá Gorilla\'s Lanches! Gostaria de fazer um pedido.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-lg active:scale-95 transition-all"
          >
            <MessageCircle className="w-5 h-5 fill-white text-white" />
            <span>{RESTAURANT_INFO.phone}</span>
          </a>
        </aside>
      )}

      {/* Mobile Floating Bottom Cart Bar - Primária #FF7A00 com Animação Shake/Bounce */}
      {cartCount > 0 && activeTab === 'catalog' && (
        <aside
          aria-label="Resumo do Pedido"
          className="fixed bottom-3 inset-x-3 sm:hidden z-30 animate-in slide-in-from-bottom-4 duration-200"
        >
          <button
            onClick={() => setIsCheckoutOpen(true)}
            className={`w-full flex items-center justify-between p-3.5 rounded-2xl bg-[#FF7A00] hover:bg-[#E04E0C] text-white font-bold shadow-xl active:scale-98 transition-all ${
              isCartAnimating ? 'animate-cart-bounce ring-4 ring-[#FFF1E6]' : ''
            }`}
          >
            <div className="flex items-center gap-2.5">
              <div className={`w-8 h-8 rounded-xl bg-white text-[#FF7A00] flex items-center justify-center font-black text-xs ${
                isCartAnimating ? 'animate-badge-pop' : ''
              }`}>
                {cartCount}
              </div>
              <div className="text-left">
                <span className="block text-[10px] uppercase font-semibold text-white/95 leading-none">
                  Ver Pedido & Checkout
                </span>
                <span className="text-sm font-bold leading-none text-white font-mono">
                  R$ {cartSubtotal.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 bg-white text-[#E04E0C] px-3 py-1.5 rounded-xl text-xs font-bold shadow-xs">
              <span>Finalizar</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </button>
        </aside>
      )}

      {/* Product Customization Modal */}
      {selectedProduct && (
        <ProductModal
          item={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        subtotal={cartSubtotal}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* Checkout Modal with Radius Delivery Calculation */}
      {isCheckoutOpen && (
        <CheckoutModal
          items={cartItems}
          subtotal={cartSubtotal}
          restaurant={RESTAURANT_INFO}
          onClose={() => setIsCheckoutOpen(false)}
          onOrderCreated={handleOrderCreated}
        />
      )}

      {/* Delivery Calculator Modal */}
      <DeliveryCalculatorModal
        restaurant={RESTAURANT_INFO}
        isOpen={isDeliveryCalcOpen}
        onClose={() => setIsDeliveryCalcOpen(false)}
      />

      {/* Project Download Modal */}
      <ProjectDownloadModal
        isOpen={isDownloadOpen}
        onClose={() => setIsDownloadOpen(false)}
      />

      {/* Share / Public Domain Modal */}
      <SharePublicModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        phone={RESTAURANT_INFO.phone}
      />

      {/* Footer - Fundo #FFFFFF, Borda suave e Ações Claras */}
      <footer className="border-t border-[#FFF1E6] bg-[#FFFFFF] py-6 text-center text-xs text-stone-600">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-semibold text-[#1F1F1F]">
            © 2026 Gorilla&apos;s Lanches • Mais Sabor, Mais Qualidade, Mais Você!
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3.5 text-[#1F1F1F]/80 font-medium">
            <span className="text-[#1F1F1F]">Rua Santo André, 199</span>
            <span>•</span>
            <button
              onClick={() => setIsDeliveryCalcOpen(true)}
              className="text-[#FF7A00] hover:text-[#E04E0C] hover:underline font-bold flex items-center gap-1 transition-colors"
            >
              <Bike className="w-3.5 h-3.5" /> Tabela de Frete (km)
            </button>
            <span>•</span>
            <button
              onClick={() => setIsDownloadOpen(true)}
              className="text-[#FF7A00] hover:text-[#E04E0C] hover:underline font-bold flex items-center gap-1 transition-colors"
            >
              <Download className="w-3.5 h-3.5" /> Baixar HTML / ZIP
            </button>
            <span>•</span>
            <a
              href={`https://wa.me/${RESTAURANT_INFO.whatsappFormatted}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-emerald-700 hover:underline flex items-center gap-1 font-bold"
            >
              <MessageCircle className="w-3.5 h-3.5" /> {RESTAURANT_INFO.phone}
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}



