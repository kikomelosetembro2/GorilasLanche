import React from 'react';
import {
  ShoppingBag,
  MessageCircle,
  MapPin,
  Sparkles,
  Receipt,
  BookOpen,
  Smartphone,
  Download,
  Globe,
  Clock,
  Flame,
  FileCode,
} from 'lucide-react';
import { RestaurantConfig } from '../types';

interface HeaderProps {
  restaurant: RestaurantConfig;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  activeTab: 'catalog' | 'receipt' | 'architecture';
  setActiveTab: (tab: 'catalog' | 'receipt' | 'architecture') => void;
  onOpenDownload: () => void;
  onOpenShare: () => void;
  isCartAnimating?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  restaurant,
  cartCount,
  cartTotal,
  onOpenCart,
  activeTab,
  setActiveTab,
  onOpenDownload,
  onOpenShare,
  isCartAnimating = false,
}) => {
  // Check if open now based on real day/time (Terça a Domingo: 18:00 às 22:00 - Fechado às Segundas)
  const now = new Date();
  const day = now.getDay();
  const isMonday = day === 1;
  const hour = now.getHours();
  const minute = now.getMinutes();
  const timeInMinutes = hour * 60 + minute;
  const isWithinHours = timeInMinutes >= 18 * 60 && timeInMinutes <= 22 * 60;
  const isOpen = !isMonday && isWithinHours;

  return (
    <header className="sticky top-0 z-40 bg-[#FFFFFF] border-b border-[#FFF1E6] shadow-xs">
      {/* Top Banner Bar - Primária #FF7A00 com detalhes em #FFF1E6 e #E04E0C */}
      <div className="bg-gradient-to-r from-[#FF7A00] via-[#FF7A00] to-[#E04E0C] text-white text-xs font-semibold py-2 px-4 shadow-inner">
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto text-nowrap gap-4">
          <span className="flex items-center gap-1.5 text-white/95">
            <Sparkles className="w-3.5 h-3.5 text-[#FFF1E6]" />
            <span>Mais Sabor, Mais Qualidade, Mais Você!</span>
            <span className="hidden md:inline-flex items-center gap-1 ml-2 px-2 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-medium border border-white/25">
              <Flame className="w-3 h-3 text-[#FFF1E6]" /> Pedidos 100% integrados com WhatsApp
            </span>
          </span>
          <div className="flex items-center gap-3 text-xs font-medium text-white/90 shrink-0">
            <span className="flex items-center gap-1 text-[#FFF1E6]">
              <Clock className="w-3.5 h-3.5 text-[#FFF1E6]" /> 18h às 22h (Ter a Dom)
            </span>
            <span className="hidden sm:inline text-white/50">•</span>
            <a
              href={`https://wa.me/${restaurant.whatsappFormatted}?text=${encodeURIComponent("Olá Gorilla's Lanches!")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:underline flex items-center gap-1 font-semibold text-white bg-black/15 px-2.5 py-0.5 rounded-md hover:bg-black/25 transition-colors"
            >
              WhatsApp: {restaurant.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Main Header Container - Fundo #FFFFFF */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-3.5">
        <div className="flex items-center justify-between gap-3">
          {/* Logo & Brand Identity */}
          <div
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => setActiveTab('catalog')}
          >
            <div className="relative">
              <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-2xl bg-[#FF7A00] p-0.5 shadow-sm group-hover:scale-105 transition-transform duration-200">
                <div className="w-full h-full bg-[#FFFFFF] rounded-[14px] flex items-center justify-center border border-[#FFF1E6]">
                  <span className="text-2xl sm:text-3xl select-none">🦍</span>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black tracking-tight text-[#1F1F1F] group-hover:text-[#FF7A00] transition-colors">
                  {restaurant.name}
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#FFF1E6] text-[#E04E0C] border border-[#FF7A00]/30">
                  OFICIAL 2026
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-stone-500 mt-0.5">
                <span className={`inline-flex items-center gap-1 font-semibold ${isOpen ? 'text-emerald-600' : 'text-[#E04E0C]'}`}>
                  <span className={`w-2 h-2 rounded-full ${isOpen ? 'bg-emerald-500' : 'bg-[#E04E0C]'} animate-pulse`} />
                  {isOpen
                    ? 'Aberto Agora (18h às 22h)'
                    : isMonday
                    ? 'Fechado às Segundas'
                    : 'Abre às 18:00'}
                </span>
                <span className="hidden sm:inline text-stone-300">•</span>
                <span className="hidden sm:flex items-center gap-1 text-[#1F1F1F]/80">
                  <MapPin className="w-3.5 h-3.5 text-[#FF7A00]" /> {restaurant.address}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions: Botão HTML/ZIP, WhatsApp, Link e Carrinho */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            {/* BOTÃO BAIXAR HTML EXECUTÁVEL / ZIP */}
            <button
              onClick={onOpenDownload}
              className="flex items-center gap-1.5 px-3 py-2 sm:py-2.5 rounded-xl bg-[#FFF1E6] hover:bg-[#FFE3CE] text-[#E04E0C] border border-[#FF7A00]/40 font-bold text-xs sm:text-sm shadow-xs transition-all active:scale-95"
              title="Baixar HTML do Aplicativo para Executar"
            >
              <FileCode className="w-4 h-4 text-[#FF7A00]" />
              <span className="hidden xs:inline">Baixar HTML</span>
              <span className="xs:hidden">HTML</span>
            </button>

            {/* BOTÃO WHATSAPP OFICIAL */}
            <a
              href={`https://wa.me/${restaurant.whatsappFormatted}?text=${encodeURIComponent("Olá Gorilla's Lanches! Gostaria de fazer um pedido pelo WhatsApp.")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3 sm:px-3.5 py-2 sm:py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200/80 font-bold text-xs sm:text-sm shadow-xs transition-all active:scale-95"
              title="Atendimento WhatsApp Direto"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <div className="text-left leading-tight hidden sm:block">
                <span className="block text-[9px] uppercase tracking-wider font-semibold text-emerald-600">WhatsApp</span>
                <span className="font-mono font-bold text-xs text-emerald-800">{restaurant.phone}</span>
              </div>
            </a>

            {/* Public Link Modal */}
            <button
              onClick={onOpenShare}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 sm:py-2.5 rounded-xl bg-[#FFF1E6] hover:bg-[#FFE3CE] text-[#1F1F1F] border border-[#FF7A00]/30 font-semibold text-xs transition-colors"
              title="Compartilhar Link Público do Cardápio"
            >
              <Globe className="w-4 h-4 text-[#FF7A00]" />
              <span>Link Público</span>
            </button>

            {/* Cart Button - Primária #FF7A00 com Hover #E04E0C + Animação Shake/Bounce */}
            <button
              onClick={onOpenCart}
              className={`relative flex items-center gap-2 px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl bg-[#FF7A00] hover:bg-[#E04E0C] text-white font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all duration-200 active:scale-95 ${
                isCartAnimating ? 'animate-cart-shake ring-4 ring-[#FFF1E6]' : ''
              }`}
              aria-label="Ver Carrinho"
            >
              <div className="relative">
                <ShoppingBag className={`w-4 h-4 text-white transition-transform ${isCartAnimating ? 'animate-cart-bounce' : ''}`} />
                {cartCount > 0 && (
                  <span
                    className={`absolute -top-2 -right-2.5 w-4 h-4 bg-[#E04E0C] border border-[#FFFFFF] text-white text-[10px] font-black rounded-full flex items-center justify-center shadow-xs ${
                      isCartAnimating ? 'animate-badge-pop scale-110' : ''
                    }`}
                  >
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="text-left hidden xs:block">
                <span className="block text-[10px] uppercase font-semibold text-white/95 leading-none">
                  {cartCount === 0 ? 'Carrinho' : `${cartCount} itens`}
                </span>
                <span className="text-xs sm:text-sm font-black leading-none text-white font-mono">
                  R$ {cartTotal.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Navigation Tabs: Segmented Control Moderno com as Novas Cores */}
        <nav className="flex items-center gap-1 sm:gap-2 mt-3 pt-2.5 border-t border-[#FFF1E6] overflow-x-auto text-nowrap pb-1 no-scrollbar">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`flex items-center gap-2 px-3.5 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'catalog'
                ? 'bg-[#FF7A00] text-white shadow-xs'
                : 'bg-[#FFF1E6] hover:bg-[#FFE3CE] text-[#1F1F1F]'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Cardápio Digital PWA</span>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-semibold ${
                activeTab === 'catalog' ? 'bg-white/25 text-white' : 'bg-white text-[#1F1F1F] border border-[#FF7A00]/20'
              }`}
            >
              Cliente
            </span>
          </button>

          <button
            onClick={() => setActiveTab('receipt')}
            className={`flex items-center gap-2 px-3.5 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'receipt'
                ? 'bg-[#FF7A00] text-white shadow-xs'
                : 'bg-[#FFF1E6] hover:bg-[#FFE3CE] text-[#1F1F1F]'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Comanda Térmica 80mm & Cozinha</span>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-semibold ${
                activeTab === 'receipt' ? 'bg-white/25 text-white' : 'bg-white text-[#1F1F1F] border border-[#FF7A00]/20'
              }`}
            >
              PDV
            </span>
          </button>

          <button
            onClick={() => setActiveTab('architecture')}
            className={`flex items-center gap-2 px-3.5 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'architecture'
                ? 'bg-[#FF7A00] text-white shadow-xs'
                : 'bg-[#FFF1E6] hover:bg-[#FFE3CE] text-[#1F1F1F]'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Manual do Sistema</span>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-semibold ${
                activeTab === 'architecture' ? 'bg-white/25 text-white' : 'bg-white text-[#1F1F1F] border border-[#FF7A00]/20'
              }`}
            >
              Guia
            </span>
          </button>

          {/* Download HTML Direct Tab Button */}
          <button
            onClick={onOpenDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm font-bold text-[#E04E0C] bg-[#FFF1E6] hover:bg-[#FFE3CE] border border-[#FF7A00]/40 transition-all ml-auto shrink-0"
          >
            <Download className="w-4 h-4 text-[#FF7A00]" />
            <span>Baixar HTML / ZIP</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
