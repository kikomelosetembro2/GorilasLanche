import React, { useState, useMemo } from 'react';
import {
  Search,
  Flame,
  Plus,
  HelpCircle,
  MessageCircle,
  Sparkles,
  MapPin,
  ArrowRight,
  Bike,
} from 'lucide-react';
import { MenuItem } from '../types';

interface MenuCatalogProps {
  items: MenuItem[];
  onSelectItem: (item: MenuItem) => void;
  onOpenDeliveryCalculator?: () => void;
}

const CATEGORIES = [
  { id: 'todos', label: 'Todos os Itens', icon: '📋' },
  { id: 'combos', label: 'Combos da Semana', icon: '⭐', highlight: true },
  { id: 'sanduiches', label: 'Sanduíches', icon: '🥪' },
  { id: 'batatas', label: 'Batata Frita', icon: '🍟' },
  { id: 'acai', label: 'Açaí Cremoso', icon: '🍧' },
  { id: 'bebidas', label: 'Bebidas Geladas', icon: '🥤' },
];

export const MenuCatalog: React.FC<MenuCatalogProps> = ({
  items,
  onSelectItem,
  onOpenDeliveryCalculator,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchesCategory = selectedCategory === 'todos' || item.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q);
      return matchesCategory && matchesSearch;
    });
  }, [items, selectedCategory, searchQuery]);

  return (
    <div className="w-full pb-24 text-[#1F1F1F]">
      {/* Promo & Combo Hero Ribbon - Cores: #FF7A00, #E04E0C, #FFF1E6, #FFFFFF, #1F1F1F */}
      <section className="mb-6 rounded-3xl bg-gradient-to-br from-[#FF7A00] via-[#FF7A00] to-[#E04E0C] p-5 sm:p-7 shadow-lg relative overflow-hidden text-white border border-[#FF7A00]/30">
        <div className="absolute -right-8 -bottom-8 opacity-15 pointer-events-none text-9xl select-none">
          🦍
        </div>
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5 relative z-10">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1F1F1F] text-[#FFF1E6] border border-white/20 text-xs font-black uppercase tracking-wider mb-2.5 shadow-sm">
              <Flame className="w-4 h-4 fill-[#FF7A00] text-[#FF7A00]" /> Promoções & Cardápio Oficial
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-white uppercase tracking-tight leading-tight drop-shadow-xs">
              Lanches Artesanais & Combos Especiais
            </h2>
            <p className="text-[#FFF1E6] font-medium text-xs sm:text-sm mt-2 leading-relaxed">
              Monte seu lanche com adicionais na chapa, retire o que não gostar e envie seu pedido com cálculo automático de frete por raio (km) direto no WhatsApp!
            </p>

            {/* Quick Delivery Radius CTA Button */}
            {onOpenDeliveryCalculator && (
              <button
                type="button"
                onClick={onOpenDeliveryCalculator}
                className="mt-3.5 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#1F1F1F] hover:bg-[#2A2A2A] text-white font-black text-xs uppercase tracking-wide shadow-sm active:scale-95 transition-all border border-white/10"
              >
                <Bike className="w-4 h-4 text-[#FF7A00]" />
                <span>Simular Frete por Raio (km)</span>
              </button>
            )}
          </div>

          {/* BOTÃO WHATSAPP ULTRA DESTACADO */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
            <a
              href="https://wa.me/5568992277408?text=Ol%C3%A1%20Gorilla%27s%20Lanches%21%20Gostaria%20de%20fazer%20um%20pedido."
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-between sm:justify-start gap-3.5 px-5 py-4 rounded-2xl bg-white hover:bg-[#FFF1E6] text-[#1F1F1F] font-black shadow-lg border border-white/30 transition-all duration-300 transform hover:scale-[1.02] active:scale-95"
              title="Pedir direto no WhatsApp (68) 99227-7408"
            >
              <div className="w-11 h-11 rounded-xl bg-emerald-500 text-white flex items-center justify-center text-xl shrink-0 shadow-sm">
                <MessageCircle className="w-6 h-6 fill-white" />
              </div>
              <div className="text-left">
                <span className="block text-[10px] uppercase font-black tracking-wider text-[#E04E0C]">
                  👉 Peça pelo WhatsApp Agora
                </span>
                <span className="font-mono text-base sm:text-lg font-black text-[#1F1F1F]">
                  (68) 99227-7408
                </span>
              </div>
              <ArrowRight className="w-5 h-5 text-[#FF7A00] stroke-[3] group-hover:translate-x-1 transition-transform" />
            </a>

            <div className="hidden xl:flex items-center gap-2.5 bg-[#1F1F1F]/70 backdrop-blur-md border border-white/15 p-3.5 rounded-2xl text-left shadow-md">
              <MapPin className="w-6 h-6 text-[#FF7A00] shrink-0 stroke-[2.5]" />
              <div className="text-xs">
                <p className="font-bold text-white">Rua Santo André, 199</p>
                <p className="text-[11px] font-medium text-[#FFF1E6]">18:00 às 22:00 (Ter a Dom)</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sticky Category & Search Navigation */}
      <div className="sticky top-[108px] sm:top-[120px] z-30 bg-[#FFFFFF]/95 backdrop-blur-md pt-2 pb-3 -mx-4 px-4 border-b border-[#FFF1E6] mb-6">
        {/* Search Input Bar (Fundo Branco, Borda e Destaques #FF7A00) */}
        <div className="relative mb-3">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#FF7A00] stroke-[2.5]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por X-Bagunça, X-Tudo, Filé, Batata, Açaí, Refri..."
            className="w-full bg-[#FFFFFF] text-[#1F1F1F] font-semibold placeholder-[#1F1F1F]/40 text-sm rounded-2xl pl-11 pr-10 py-3 border border-[#FFF1E6] shadow-xs focus:border-[#FF7A00] focus:ring-2 focus:ring-[#FF7A00]/20 outline-none transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-white bg-[#1F1F1F] hover:bg-[#E04E0C] rounded-full w-6 h-6 flex items-center justify-center transition-colors"
            >
              ×
            </button>
          )}
        </div>

        {/* Scrollable Category Filter Pills: #FF7A00 ativo e #FFF1E6 inativo */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 text-nowrap">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all duration-200 active:scale-95 ${
                  isSelected
                    ? 'bg-[#FF7A00] text-white shadow-md scale-[1.02]'
                    : 'bg-[#FFF1E6] text-[#1F1F1F] hover:bg-[#FFE3CE] border border-[#FF7A00]/20'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Product Grid - Responsive Cards (Fundo #FFFFFF, Detalhes #FFF1E6, Ações #FF7A00 / #E04E0C, Texto #1F1F1F) */}
      {filteredItems.length === 0 ? (
        <div className="text-center py-16 bg-[#FFF1E6] rounded-3xl border border-[#FF7A00]/30 p-8 shadow-xs">
          <HelpCircle className="w-12 h-12 text-[#E04E0C] mx-auto mb-3" />
          <h3 className="text-xl font-black text-[#1F1F1F] mb-1">Nenhum item encontrado</h3>
          <p className="text-xs font-medium text-[#1F1F1F]/70 max-w-sm mx-auto">
            Não encontramos nenhum produto correspondente a &quot;{searchQuery}&quot;. Tente outro termo ou limpe os filtros.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('todos');
            }}
            className="mt-4 px-5 py-2.5 rounded-xl bg-[#FF7A00] hover:bg-[#E04E0C] text-white font-bold text-xs uppercase shadow-xs transition-all active:scale-95"
          >
            Limpar Busca
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredItems.map((item) => {
            return (
              <article
                key={item.id}
                onClick={() => onSelectItem(item)}
                className="group relative bg-[#FFFFFF] hover:bg-white rounded-3xl p-5 border border-stone-200 hover:border-[#FF7A00] transition-all duration-200 cursor-pointer shadow-xs hover:shadow-lg flex flex-col justify-between active:scale-[0.99]"
              >
                {/* Header with Title and Promo Badge */}
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <h3 className="text-lg sm:text-xl font-black text-[#1F1F1F] uppercase tracking-tight group-hover:text-[#FF7A00] transition-colors">
                      {item.name}
                    </h3>
                    {item.badge && (
                      <span className="shrink-0 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#FF7A00] text-white shadow-xs">
                        {item.badge}
                      </span>
                    )}
                  </div>

                  {/* Description / Ingredients */}
                  <p className="text-xs font-normal text-[#1F1F1F]/75 leading-relaxed line-clamp-3 mb-4">
                    {item.description}
                  </p>
                </div>

                {/* Footer with Price and Customize/Add CTA - "O laranja destaca os botões de pedido e as promoções" */}
                <div className="pt-3 border-t border-[#FFF1E6] flex items-center justify-between gap-2 mt-auto">
                  <div>
                    <span className="block text-[10px] text-[#1F1F1F]/60 uppercase font-bold tracking-wider">
                      {item.sizes ? 'A partir de' : 'Preço'}
                    </span>
                    <div className="inline-block px-2.5 py-0.5 rounded-lg bg-[#FFF1E6] text-[#E04E0C] font-black text-base font-mono border border-[#FF7A00]/30">
                      R$ {item.price.toFixed(2).replace('.', ',')}
                    </div>
                  </div>

                  {/* Botão de Pedido Destacado em Laranja #FF7A00 */}
                  <button
                    type="button"
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#FF7A00] hover:bg-[#E04E0C] text-white font-black text-xs uppercase tracking-wide shadow-sm hover:shadow-md transition-all duration-200 active:scale-95"
                  >
                    <Plus className="w-4 h-4 stroke-[3]" />
                    <span>Adicionar</span>
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
