import React, { useState, useMemo } from 'react';
import { X, Plus, Minus, Check, ShoppingBag, Utensils, MessageCircle, Star } from 'lucide-react';
import { MenuItem, CartAddon, CartItem } from '../types';
import { COMMON_ADDONS, AddonDefinition, RESTAURANT_INFO } from '../data/menuData';

interface ProductModalProps {
  item: MenuItem | null;
  onClose: () => void;
  onAddToCart: (cartItem: CartItem) => void;
}

const CATEGORY_TABS = [
  { id: 'todos', label: 'Todos os Adicionais', icon: '✨' },
  { id: 'proteinas', label: 'Carnes & Proteínas', icon: '🥩' },
  { id: 'queijos_cremes', label: 'Queijos & Cremes', icon: '🧀' },
  { id: 'chapa_extras', label: 'Chapa & Crocantes', icon: '🍳' },
  { id: 'molhos', label: 'Molhos Especiais', icon: '🥫' },
];

export const ProductModal: React.FC<ProductModalProps> = ({ item, onClose, onAddToCart }) => {
  if (!item) return null;

  // Selected size (default to first if available)
  const [selectedSize, setSelectedSize] = useState<{ label: string; price: number } | undefined>(
    item.sizes && item.sizes.length > 0 ? item.sizes[0] : undefined
  );

  // Addon quantities map: addonId -> count
  const [addonQuantities, setAddonQuantities] = useState<Record<string, number>>({});

  // Active category tab for the addon tool
  const [activeAddonTab, setActiveAddonTab] = useState<string>('todos');

  // Removed ingredients
  const [removedIngredients, setRemovedIngredients] = useState<string[]>([]);

  // Notes
  const [notes, setNotes] = useState<string>('');

  // Overall product quantity
  const [quantity, setQuantity] = useState<number>(1);

  // Available addons for this item
  const availableAddonsList: AddonDefinition[] = useMemo(() => {
    if (!item.availableAddons || item.availableAddons.length === 0) return [];
    return COMMON_ADDONS.filter((addon) => item.availableAddons?.includes(addon.id));
  }, [item]);

  // Filter addons by tab
  const filteredAddons = useMemo(() => {
    if (activeAddonTab === 'todos') return availableAddonsList;
    return availableAddonsList.filter((a) => a.category === activeAddonTab);
  }, [availableAddonsList, activeAddonTab]);

  // Total addons count and price
  const { totalAddonsPrice, totalAddonsSelectedCount } = useMemo(() => {
    let price = 0;
    let count = 0;
    Object.entries(addonQuantities).forEach(([id, qty]) => {
      if (qty > 0) {
        const addon = availableAddonsList.find((a) => a.id === id);
        if (addon) {
          price += addon.price * qty;
          count += qty;
        }
      }
    });
    return { totalAddonsPrice: price, totalAddonsSelectedCount: count };
  }, [addonQuantities, availableAddonsList]);

  // Unit base price (size price or item default price)
  const unitBasePrice = selectedSize ? selectedSize.price : item.price;
  const unitPrice = unitBasePrice + totalAddonsPrice;
  const totalPrice = unitPrice * quantity;

  // Handlers for Addon Quantity
  const handleIncreaseAddon = (addonId: string, maxQty: number = 5) => {
    setAddonQuantities((prev) => {
      const current = prev[addonId] || 0;
      if (current >= maxQty) return prev;
      return { ...prev, [addonId]: current + 1 };
    });
  };

  const handleDecreaseAddon = (addonId: string) => {
    setAddonQuantities((prev) => {
      const current = prev[addonId] || 0;
      if (current <= 1) {
        const copy = { ...prev };
        delete copy[addonId];
        return copy;
      }
      return { ...prev, [addonId]: current - 1 };
    });
  };

  // Toggle removed ingredients
  const handleToggleRemoveIngredient = (ing: string) => {
    setRemovedIngredients((prev) =>
      prev.includes(ing) ? prev.filter((i) => i !== ing) : [...prev, ing]
    );
  };

  // Build the CartAddon array
  const getSelectedAddonsArray = (): CartAddon[] => {
    const list: CartAddon[] = [];
    Object.entries(addonQuantities).forEach(([id, qty]) => {
      if (qty > 0) {
        const addon = availableAddonsList.find((a) => a.id === id);
        if (addon) {
          list.push({
            id: addon.id,
            name: qty > 1 ? `${addon.name} (${qty}x)` : addon.name,
            price: addon.price * qty,
            quantity: qty,
          });
        }
      }
    });
    return list;
  };

  const handleConfirm = () => {
    const cartItem: CartItem = {
      cartItemId: `${item.id}-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      product: item,
      quantity,
      selectedSize,
      selectedAddons: getSelectedAddonsArray(),
      removedIngredients,
      notes: notes.trim() || undefined,
      unitPrice,
      totalPrice,
    };
    onAddToCart(cartItem);
    onClose();
  };

  // Quick Direct WhatsApp Order for this item
  const handleQuickOrderWhatsApp = () => {
    const addons = getSelectedAddonsArray();
    const lines = [
      `🍔 *PEDIDO RÁPIDO - GORILLA'S LANCHES*`,
      `*Item:* ${quantity}x ${item.name}${selectedSize ? ` (${selectedSize.label})` : ''}`,
      `*Valor:* R$ ${totalPrice.toFixed(2).replace('.', ',')}`,
    ];

    if (addons.length > 0) {
      lines.push(`*Adicionais Extras:*`);
      addons.forEach((a) => lines.push(` ➕ ${a.name} (+R$ ${a.price.toFixed(2).replace('.', ',')})`));
    }

    if (removedIngredients.length > 0) {
      lines.push(`*Retirar Ingredientes:* ${removedIngredients.join(', ')}`);
    }

    if (notes.trim()) {
      lines.push(`*Obs:* ${notes.trim()}`);
    }

    lines.push(`\n_Gostaria de pedir este lanche para entrega! Meu número/nome:_`);
    const waUrl = `https://wa.me/${RESTAURANT_INFO.whatsappFormatted}?text=${encodeURIComponent(lines.join('\n'))}`;
    window.location.href = waUrl;
  };

  const isSandwichOrCombo = item.category === 'sanduiches' || item.category === 'combos';

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-stone-900/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full sm:max-w-2xl bg-[#FFFFFF] rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[92vh] flex flex-col overflow-hidden border border-[#FFF1E6]">
        {/* Modal Header: Fundo #FFFFFF com Destaques #FF7A00 */}
        <div className="p-4 sm:p-5 border-b border-[#FFF1E6] bg-[#FFFFFF] flex items-center justify-between gap-3 sticky top-0 z-20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FFF1E6] text-[#FF7A00] border border-[#FF7A00]/30 flex items-center justify-center text-lg shrink-0">
              {item.category === 'sanduiches' ? '🥪' : item.category === 'combos' ? '⭐' : '🍟'}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-semibold text-[#1F1F1F]/60">
                  {isSandwichOrCombo ? 'Personalize seu Sanduíche' : 'Personalize seu Pedido'}
                </span>
                <span className="inline-flex items-center gap-0.5 text-[10px] text-[#FF7A00] font-black bg-[#FFF1E6] px-1.5 py-0.2 rounded border border-[#FF7A00]/30">
                  <Star className="w-2.5 h-2.5 fill-[#FF7A00]" /> 4.9
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-black text-[#1F1F1F] line-clamp-1">
                {item.name}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-[#FFF1E6] hover:bg-[#FFE3CE] text-[#1F1F1F] flex items-center justify-center transition-colors active:scale-95"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content Body - Fundo #FFFFFF */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 bg-[#FFFFFF]">
          {/* Ingredients / Description Banner */}
          <div className="bg-[#FFFFFF] rounded-2xl p-4 border border-[#FFF1E6] shadow-xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[#1F1F1F] font-bold text-xs flex items-center gap-1.5">
                <Utensils className="w-3.5 h-3.5 text-[#FF7A00]" /> Ingredientes da Chapa Gorilla:
              </span>
              <span className="font-mono font-bold text-[#E04E0C] bg-[#FFF1E6] text-xs px-2.5 py-0.5 rounded-md border border-[#FF7A00]/30">
                R$ {unitBasePrice.toFixed(2).replace('.', ',')}
              </span>
            </div>
            <p className="text-[#1F1F1F]/80 text-xs sm:text-sm leading-relaxed">{item.description}</p>
          </div>

          {/* Size Options (if applicable) */}
          {item.sizes && item.sizes.length > 0 && (
            <div className="bg-[#FFFFFF] p-4 rounded-2xl border border-[#FFF1E6] shadow-xs">
              <label className="block text-xs font-bold text-[#1F1F1F] mb-2">
                Escolha o Tamanho:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {item.sizes.map((size) => {
                  const isSelected = selectedSize?.label === size.label;
                  return (
                    <button
                      key={size.label}
                      type="button"
                      onClick={() => setSelectedSize(size)}
                      className={`p-3 rounded-xl border text-left font-medium transition-all ${
                        isSelected
                          ? 'border-[#FF7A00] bg-[#FFF1E6] text-[#1F1F1F] shadow-xs font-bold'
                          : 'border-stone-200 bg-white hover:bg-[#FFF1E6]/50 text-[#1F1F1F]/80'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold">{size.label}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#FF7A00]" />}
                      </div>
                      <span className="text-xs text-[#E04E0C] font-mono mt-0.5 block font-bold">
                        R$ {size.price.toFixed(2).replace('.', ',')}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Remove Ingredients Option - Secundária #E04E0C para remoções */}
          {item.removableIngredients && item.removableIngredients.length > 0 && (
            <div className="bg-[#FFFFFF] p-4 rounded-2xl border border-[#FFF1E6] shadow-xs">
              <span className="block text-xs font-bold text-[#1F1F1F] mb-2">
                Deseja retirar algum ingrediente? (Sem custo)
              </span>
              <div className="flex flex-wrap gap-1.5">
                {item.removableIngredients.map((ing) => {
                  const isRemoved = removedIngredients.includes(ing);
                  return (
                    <button
                      key={ing}
                      type="button"
                      onClick={() => handleToggleRemoveIngredient(ing)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        isRemoved
                          ? 'bg-[#FFF1E6] text-[#E04E0C] border border-[#E04E0C]/40 font-bold'
                          : 'bg-stone-50 text-[#1F1F1F]/70 border border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      {isRemoved ? `✕ Sem ${ing}` : `Com ${ing}`}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Interactive Addons Tool */}
          {availableAddonsList.length > 0 && (
            <div className="bg-[#FFFFFF] p-4 sm:p-5 rounded-2xl border border-[#FFF1E6] shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-[#1F1F1F]">
                    Turbine seu Lanche (Adicionais na Chapa)
                  </h4>
                  <p className="text-[11px] text-[#1F1F1F]/60">
                    Selecione porções extras preparadas na hora
                  </p>
                </div>
                {totalAddonsSelectedCount > 0 && (
                  <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-[#FFF1E6] text-[#E04E0C] border border-[#FF7A00]/30">
                    +{totalAddonsSelectedCount} selecionados (+R$ {totalAddonsPrice.toFixed(2).replace('.', ',')})
                  </span>
                )}
              </div>

              {/* Addon Category Filter Tabs */}
              <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-1 text-nowrap">
                {CATEGORY_TABS.map((tab) => {
                  const countInCat = availableAddonsList.filter(
                    (a) => tab.id === 'todos' || a.category === tab.id
                  ).length;
                  if (countInCat === 0 && tab.id !== 'todos') return null;

                  const isActive = activeAddonTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setActiveAddonTab(tab.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                        isActive
                          ? 'bg-[#FF7A00] text-white shadow-xs'
                          : 'bg-[#FFF1E6] text-[#1F1F1F] hover:bg-[#FFE3CE]'
                      }`}
                    >
                      <span>{tab.icon}</span> <span className="ml-1">{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Addons List */}
              <div className="space-y-2 pt-1 max-h-60 overflow-y-auto pr-1">
                {filteredAddons.map((addon) => {
                  const qty = addonQuantities[addon.id] || 0;
                  return (
                    <div
                      key={addon.id}
                      className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${
                        qty > 0
                          ? 'border-[#FF7A00]/50 bg-[#FFF1E6]'
                          : 'border-stone-100 bg-[#FFFFFF] hover:bg-[#FFF1E6]/30'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-base select-none">{addon.icon || '➕'}</span>
                        <div>
                          <p className="text-xs font-bold text-[#1F1F1F] leading-tight">
                            {addon.name}
                          </p>
                          <span className="text-xs text-[#E04E0C] font-mono font-bold">
                            +R$ {addon.price.toFixed(2).replace('.', ',')}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {qty > 0 && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleDecreaseAddon(addon.id)}
                              className="w-7 h-7 rounded-lg bg-[#FFF1E6] hover:bg-[#FFE3CE] text-[#1F1F1F] flex items-center justify-center transition-colors"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-5 text-center text-xs font-black text-[#1F1F1F] font-mono">
                              {qty}
                            </span>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => handleIncreaseAddon(addon.id, addon.maxQuantity || 5)}
                          className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold transition-colors ${
                            qty > 0
                              ? 'bg-[#FF7A00] hover:bg-[#E04E0C] text-white'
                              : 'bg-[#FFF1E6] hover:bg-[#FFE3CE] text-[#1F1F1F]'
                          }`}
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Observations */}
          <div className="bg-[#FFFFFF] p-4 rounded-2xl border border-[#FFF1E6] shadow-xs">
            <label className="block text-xs font-bold text-[#1F1F1F] mb-1.5">
              Observações do pedido (Opcional):
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Ponto da carne bem passado, pouco molho, etc."
              className="w-full bg-[#FFFFFF] text-[#1F1F1F] placeholder-[#1F1F1F]/40 text-xs rounded-xl px-3 py-2 border border-[#FFF1E6] focus:border-[#FF7A00] focus:ring-2 focus:ring-[#FF7A00]/20 outline-none"
            />
          </div>
        </div>

        {/* Modal Sticky Footer - "O laranja destaca os botões de pedido e as promoções" */}
        <div className="p-4 sm:p-5 border-t border-[#FFF1E6] bg-[#FFFFFF] flex flex-col sm:flex-row items-center justify-between gap-3 sticky bottom-0 z-20">
          {/* Quantity Selector & Total */}
          <div className="flex items-center justify-between sm:justify-start gap-4 w-full sm:w-auto">
            <div className="flex items-center bg-[#FFF1E6] rounded-xl p-1 gap-1 border border-[#FF7A00]/20">
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-8 h-8 rounded-lg bg-white text-[#1F1F1F] hover:bg-[#FFE3CE] flex items-center justify-center shadow-xs transition-colors"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="w-7 text-center font-black text-[#1F1F1F] font-mono text-sm">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity((q) => q + 1)}
                className="w-8 h-8 rounded-lg bg-white text-[#1F1F1F] hover:bg-[#FFE3CE] flex items-center justify-center shadow-xs transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="text-right sm:text-left">
              <span className="block text-[10px] text-[#1F1F1F]/50 font-bold uppercase">Total do Item</span>
              <span className="text-lg font-black text-[#E04E0C] font-mono">
                R$ {totalPrice.toFixed(2).replace('.', ',')}
              </span>
            </div>
          </div>

          {/* Action CTAs: Botão de pedido em Laranja #FF7A00 */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleQuickOrderWhatsApp}
              className="px-3.5 py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
              title="Pedir este lanche direto no WhatsApp"
            >
              <MessageCircle className="w-4 h-4 text-emerald-600" />
              <span className="hidden xs:inline">WhatsApp Direto</span>
            </button>

            <button
              type="button"
              onClick={handleConfirm}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#FF7A00] hover:bg-[#E04E0C] text-white font-black text-xs sm:text-sm shadow-md hover:shadow-lg transition-all duration-200 active:scale-98"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Adicionar ao Carrinho</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

